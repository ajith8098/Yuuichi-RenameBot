<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

# 𝐒𝐈𝐆𝐌𝐀 𝐒𝐍𝐎𝐖 𝐁𝐎𝐓


### Sᴀᴍᴩʟᴇ Bᴏᴛ (Official Sɪɢᴍᴀ Sɴᴏᴡ Bᴏᴛ)

<p align="center">
🤖 <a href="https://t.me/SigmaSnowBot"><img title="Telegram" src="https://img.shields.io/static/v1?label=SigmaSnow&message=BOT&color=blue-green"></a> 🤖
</p>


## Deploy To Render              

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/Snowball-0/Sigma-Snow-Bot)

## Deploy To Railway

<a href="https://graph.org/file/fabd75cd5043d2cfdc13d.jpg"><img src="https://railway.app/button.svg" alt="Deploy"></a>

## Deploy To Heroku

<a href="https://heroku.com/deploy?template=https://github.com/Snowball-0/Sigma-Snow-Bot"><img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy"></a>



## Configs 

* `BOT_TOKEN`  - Get Bot Token From @BotFather

* `API_ID` - From my.telegram.org 

* `API_HASH` - From my.telegram.org

* `WEBHOOK` - If Your Server Is Need Web Service! Value = `True` Else Value = `False`

* `ADMIN` - AUTH Or Bot Controllers Id's Multiple Id Use Space To Split 

* `DB_URL`  - Mongo Database URL From https://cloud.mongodb.com

* `DB_NAME`  - Your Database Name From Mongodb. 

* `FORCE_SUB` - Your Force Sub Channel Username Without @

* `LOG_CHANNEL` - Bot Logs Sending Channel. If You Don't Need This To Remove This Variable In Your Server

* `START_PIC` - Start Message Photo. You Don't Need This! Just Skip

* `STRING_API_ID - Your Premium Account API ID

* `STRING_API_HASH` - Your Premium Account API HASH

* `STRING_SESSION` - Your Premium Account SESSION STRING Generate by [SnowStringGenBot](https://t.me/SnowStringGenBot) ⚠️ OPTIONAL VARIABLE

## Botfather Commands
```
start - Bot Alive Cheking
view_thumb - View Thumbnail
del_thumb - Delete Thumbnail
set_caption - Set A Custom Caption
see_caption - See Your Custom Caption
del_caption - Delete Custom Caption
metadata - To Set & Change your metadata code
set_prefix - To Set Your Prefix
set_suffix - To Set Your Suffix
see_prefix - To See Your Prefix
see_suffix - To See Your Suffix
del_prefix - Delete Your Prefix
del_suffix - Delete Your Suffix
restart - To Rrstart The Bot (Admin Only)
status - Check Bot Status (Admin Only)
broadcast - Send Message To All Users (Admin Only)
```

## Created By ❄️
- `Snowball` 
